# Verification

Renamed the fourth control to Motion and reversed its pressed-state semantics: active means animation enabled. Browser checks confirmed active=true with reduced=false and active=false with reduced=true; restored the user's original setting afterward. Instructions and README use the new label. Production build passes.

History typography increased by 2 px throughout: titles 15 px, row numbers 11 px, delete controls 13 px, empty text 16 px, and close control 20 px. Widened the panel to 440 px. Browser computed sizes match and row controls do not overlap. Production build passes.

Citation hover: added a 0.5 s looping, stepped transform capped at 1 px in each direction, shared by answer and source tiles. Verified the loaded hover/keyframe rules, citation switching, and the Reduce Motion override. Automated background clicks did not maintain `:hover`, so continuous pointer-hover motion was not visually verified. Production build passes.

History deletion: added a separate outlined Departure Mono button to each row. In an isolated test tab, deleting an inactive conversation preserved the active question and citation; reloading retained the deletion. Deleting the remaining active conversation with Enter returned to the welcome view, removed its source frame, displayed the empty state, and focused the history close button. Production build passes.

Cursor timing updated: steady while characters are appearing, then blinking only after the complete sentence settles. Across 249 samples, typing stayed fully opaque with no animation; the completed cursor entered its blink cycle without moving any text. Reduce Motion disabled blinking and kept opacity at 1. This supersedes the earlier always-steady behavior. Production build passes.

Raised all four 12 px text styles to 14 px: course title, course-material labels, source eyebrow, and attached-quotation labels. Expanded the title's available width to retain its two-line layout. Confirmed computed title/material-label sizes and no control overlap; production build passes.

Restored the typewriter cursor as a steady, absolutely positioned bar. It stays 4 px beyond the latest visible character without changing the text layout. Across 185 samples covering 78 reveal counts, exactly one cursor remained visible and every character stayed in place through completion. Reduce Motion retains the static cursor. This supersedes the earlier cursor-removal check. Production build passes.

Navigation spacing reduced: number intervals now measure 125.91 px, with equal columns and no overflowing labels. Removed the Reduce Motion square; pressed state remains accessible and uses accent text. Production build passes.

Current citation colors: selected pairs are solid green; all others are dimmed. This supersedes the earlier selected-dimmed checks below. Verified answer citation 2 followed by source citation 3: both panes matched, and the previous pair dimmed immediately. Instructions and README match this behavior. Production build passes.

Checked in Chrome on 2026-10-05.

- `npm run build`: passes TypeScript and Vite production build.
- Production page reload with an existing conversation: succeeds, no browser console errors or warnings.
- Two conversations and history switching: restored the selected four-turn conversation.
- Browser reload: retained four turns, two attached quotations, dark mode, and Reduce Motion through sessionStorage.
- Earlier-answer citations: an answer-one citation still opened its own source after follow-up turns.
- Selection question: selecting a passage displayed the small composer; both Enter and the Send button added a turn with the correct quotation and original source.
- Native cross-boundary drag: dragging from the source passage into the answer area highlighted only source text. The answer remained visually unchanged; the selection composer appeared on release.
- Reduce Motion: canvas reported its static state, typewriter displayed the complete slogan, and cursor CSS animation was `none`.
- Both themes inspected at the browser's native 2048 × 1055 desktop viewport, with no page overflow.
- Declared font faces were present and the browser's font checks passed for Departure Mono, Newsreader, Anthropic Sans, and Noto Sans SC after a Chinese input test. Chinese serif uses the explicitly approved Noto Serif SC family.

Testing found and fixed the isolated frame's native-form submission restriction and its initial document/theme race. There are no backend calls in this visual prototype. Real retrieval, answer quality, API compatibility, streaming, and authentication have not been implemented or tested.

## Readable demo copy — 2026-10-05

- Production build passes after replacing symbols with Chinese interface copy, example questions, and labelled sample answers.
- Three source cards use verified English GDPR excerpts and link to EUR-Lex; source cards explicitly say `excerpt`. Lecture passages are not fabricated.
- Checked the welcome layout in dark mode and the conversation layout in light mode. Adjusted Chinese helper text sizes and gave the slogan an intentional two-line break.
- Clicking citation 2 opened Article 17 paragraph 3. Selecting its text opened the nearby composer; Send added a second turn with the selected quotation and the fixed-demo notice.
- Clicking citation 3 in the earlier answer still opened Recital 65 after that follow-up. No browser warnings or errors were recorded.

## Cursor and interface cleanup — 2026-10-05

- The typewriter now uses a 2 px CSS cursor with a separate inline layout box. Browser measurements while typing and on the second line showed a 6 px gap from the text. Reduce Motion displays the complete slogan with no cursor animation.
- Removed prototype notices from the welcome, follow-up, and answer views at the owner's request. The README still documents the fixed-answer behavior.
- History rows now contain only their list number and title. The unlabeled turn count and decorative arrow were removed; existing conversations were preserved.
- Production build passes after these changes.

## English interface — 2026-10-05

- Switched interface copy, examples, and fixed answers to English at the owner's request. Short intro/help text uses Departure Mono; no Chinese pixel font was added.
- Production build passes. Browser checks confirmed the English welcome, answer, source, and history views; citation 2 opens Article 17 paragraph 3. No browser warnings or errors were recorded.
- Known older example questions migrate to their English equivalents in saved history; other user-entered titles remain unchanged. History has no trailing counts or arrows.
- The two-line English slogan fits the left panel, with a measured 6 px cursor gap. Existing Reduce Motion behavior remains intact.

## Instructions placement — 2026-10-05

- Moved the welcome guidance to an instructions control beside Reduce Motion; the central welcome heading is removed.
- Checked opening the panel, closing with Escape and returning focus, and switching to history without leaving both panels open. Header fits the desktop viewport; no browser warnings or errors were recorded.
- TypeScript and production build pass. Refreshed the live preview with the existing conversation preserved.

## Chinese queries and pixel guidance — 2026-10-05

- Restored Chinese example questions, input prompts, and answer bodies. English source passages and controls remain. Known saved English examples migrate back to Chinese; other user-entered text is preserved.
- Replaced the former slogan and duplicate intro paragraph with the single “Explore GDPR…” line in 22 px Departure Mono. A hidden layout copy reserves its final height during typing, and the cursor stays 6 px beyond the last character.
- Browser checks confirmed the new guidance, Chinese examples and answers, English sources, and the approved Noto Serif SC/Noto Sans SC font availability. Reduce Motion shows the full guidance with no cursor animation.
- TypeScript and production build pass; no browser warnings or errors were recorded.

## Serif and citation tiles — 2026-10-05

- Replaced the active Newsreader stack with Anthropic Serif, verified from Anthropic's official stylesheet and font-file metadata. The browser confirmed that Anthropic Serif loaded. Chinese answers retain the approved Noto Serif SC.
- Removed the source/passage label, source counter, chat counter, per-turn decorative numbers, and duplicated citation number in the source heading.
- Both citation locations use the same 24 px solid square component and styles. Clicking from either side dims the matching pair; measurements confirmed identical size, fill, and text color.
- Read state survives reloads, remains separate for each answer, and follows earlier-answer source switching after a follow-up. Checked light and dark rendering.
- TypeScript and production build pass; no browser warnings or errors were recorded.

## Selection composer dismissal — 2026-10-05

- Follow-up placeholders and send controls use 11 px Departure Mono in the main document and isolated source frame. Typed Chinese remains in the approved sans-serif stack. The popup heading is `ask about this passage`.
- Verified native mouse selection, typing within the popup, dismissal by clicks in the answer pane and within the source frame, and no stale-selection reopening. An unsent draft was dismissed without creating a turn.
- A source-to-answer drag selected only source text and opened the local popup, without highlighting the answer. Sending a Chinese follow-up closed the popup and added the second turn with its selected quote.
- TypeScript and production build pass; no browser warnings or errors were recorded.

## Instructions document and quieter panes — 2026-10-05

- Removed repeated citation and selection hints from the answer and source panes. Usage guidance now appears in a native modal document with five prose paragraphs and no list items.
- Verified the document is centered in the viewport and uses the browser's top layer; Escape dismisses it and returns focus to the instructions control. Opening it closes history.
- Source and history cards have identical computed offset shadows. The initial question placeholder is English, while example questions and answer bodies remain Chinese.
- Enlarged both follow-up placeholders to 14 px Departure Mono. Send controls remain 11 px.
- TypeScript and production build pass; no browser warnings or errors were recorded.

## Pixel instructions and selected citations — 2026-10-05

- Instructions body now uses 18 px Departure Mono; verified the computed family and loaded font in the browser. Prose and the centered modal layout are preserved.
- Citation colors now follow the current selection: solid accent for the selected pair, muted fill for all others. Previously opened citations no longer remain dim because of read history. Both panes had identical computed selected and unselected colors after switching citations.
- Posted queries and answers both measure 19 px with 34.2 px line height, retaining their sans-serif and serif roles.
- TypeScript and production build pass.

## Current citation pair dimming — 2026-10-05

- Corrected the selected-state direction: only the current citation pair dims; all others use solid green. Styling follows the shared active citation, not accumulated read history.
- In a fresh browser tab, clicked answer citation 2, then source citation 3. Computed colors confirmed both copies of 2 dimmed together, then both returned to solid green while both copies of 3 dimmed.
- Updated the instructions to describe this behavior. TypeScript and production build pass.

## Passage composer sizing — 2026-10-05

- Removed the 45 px quote limit. The composer grows naturally, with its height capped at the source viewport minus 24 px; only the quote can shrink and scroll. Positioning measures the rendered height and keeps the popup in view, including font loading and viewport changes.
- Checked the actual SourcePane component in a temporary sizing fixture. A normal excerpt used 152 px of quote height with no overflow. A long selection filled a 650 px frame with a 626 px popup; only the quote scrolled. In a 320 px frame, the popup stayed between y=12 and y=308 and its form remained visible. The temporary fixture was removed.
- Confirmed the production preview displays the full selected Recital 65 excerpt without a quote scrollbar. Clicking its question field keeps the popup open. No browser warnings or errors were recorded in the sizing check; TypeScript and production build pass.

## Claude Chinese typography — 2026-10-05

- Directly inspected live Claude CSS tokens on its public sign-in page, including response, user-message, and CJK fallback tokens. Replaced Noto Serif SC / Noto Sans SC in the active parent and iframe stacks with those verified declarations.
- Confirmed Microsoft YaHei is installed in the Windows font registry. No system fonts were redistributed.
- Browser computed styles match the new response and user-message stacks in both documents; queries and answers remain 19 px. Visually checked Chinese queries and answers with English source text, and confirmed citation switching still works.
- TypeScript and production build pass; no browser warnings or errors were recorded.

## Highlight while composing — 2026-10-05

- Retain the selected source range using the iframe's CSS Custom Highlight registry. Input focus no longer removes the visual highlight; the source DOM and parent answer selection are unchanged. The registry entry is removed when the selection composer closes or the source component unmounts.
- Selected a source excerpt, focused the adjacent question field, and typed a Chinese follow-up. The source stayed visibly highlighted while the answer panel remained unhighlighted. Escape removed both the composer and the source highlight.
- TypeScript and production build pass; no browser warnings or errors were recorded. The implementation uses the [CSS Custom Highlight API](https://developer.mozilla.org/en-US/docs/Web/API/CSS_Custom_Highlight_API), available in the tested in-app browser.

## Evenly spaced numbered navigation — 2026-10-05

- Added `[5]` to instructions and placed all five controls in one equal-column grid. Each column accommodates the longest label, including the Reduce Motion indicator. Removed the former nested settings spacing.
- At a measured 1120 px CSS viewport, every number-to-number interval measured 156.53 px. No button content overflowed; the title wrapped within its own area, stayed within the 82 px header, and remained 20 px from navigation.
- Theme and motion state changes preserved those equal intervals. The `[5] instructions` button opened its existing document correctly. Restored the browser's normal viewport after checking.
- TypeScript and production build pass.

## Empty history typography — 2026-10-05

- Replaced the oversized serif empty-history heading with a single 14 px Departure Mono status line. Removed the redundant explanatory sentence.
- Verified the empty history in a fresh preview tab; computed font is Departure Mono, and no browser warnings or errors were recorded. TypeScript and production build pass.

## Stable typewriter and readable quotations — 2026-10-05

- Removed the blinking slogan cursor. The entire sentence now occupies its final layout from the start, with individual characters revealed inside unbroken words. Typing starts after Departure Mono loads and retains the 35 ms interval.
- Sampled 80 animation frames across 29 reveal counts, then checked completion. Every character kept the same coordinates and the heading kept its height. Reduce Motion showed the full sentence with no cursor.
- Submitted quotations now use 19 px text with a 12 px Departure Mono source label. Increased their height allowance to 180 px; the tested Article 17 excerpt fit naturally at 129 px with no internal scrolling.
- Verified quote submission, preserved the user's conversation while refreshing the preview, and recorded no browser warnings or errors. TypeScript and production build pass.

## Immediate cursor blink at completion — 2026-10-05

- The cursor stays visible during typing and becomes invisible immediately when the final character appears. Removed the animation delay and started the repeating blink in its invisible phase; subsequent visibility changes occur every 550 ms.
- Sampled 322 browser states across completion: the final typing sample had opacity 1, the first completed sample had opacity 0 with a 0 s delay, and subsequent samples alternated between 0 and 1. The heading height stayed at 165 px. Motion off retained a visible static cursor with no animation.
- TypeScript and production build pass. Refreshed the open preview after checking for unsent input; no browser warnings or errors were recorded.

## Minimum text size — 2026-10-05

- Raised every font declaration below 14 px in the application and isolated source document to 14 px, including navigation, list indices, example questions, send/delete buttons, citation numbers, external source links, selection headings, and instruction close controls. Existing larger sizes remain unchanged.
- Audited computed text and placeholder sizes on the welcome screen, instructions, empty/populated history, conversation, source passage, and selection composer. No text below 14 px was found.
- At 1120 × 740, navigation numbers have equal 103.08 px intervals. The title remains two lines within the 82 px header; navigation labels and history controls have no horizontal overflow. The selection composer fits its source viewport with no header overflow. Reset the temporary viewport afterward.
- TypeScript and production build pass. The open preview was refreshed after checking for unsent input and has no browser warnings or errors. The handoff archive includes these changes.
