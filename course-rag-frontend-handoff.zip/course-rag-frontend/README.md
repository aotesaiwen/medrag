# Medical Data Privacy and Ethics in the Age of Artificial Intelligence

Student-facing course RAG frontend prototype.

React 19, Vite, TypeScript. No UI component library. This is a standalone frontend repository, with no backend integration or model calls.

All interface text has a 14 px minimum, including navigation, citation numbers, buttons, list indices, and controls inside the source document. Larger existing text retains its size.

## Run

```sh
npm ci
npm run dev
```

`npm run build` runs TypeScript and produces `dist/`. `npm run preview` serves the production build.

## Review the prototype

- `[1] chat` starts a new conversation. Existing conversations remain in `[2] history`.
- Each history row has an outlined `delete` button. Deleting the open conversation returns to a new chat; deleting another preserves the open conversation and citation. Deletions persist in this tab's session storage, and keyboard focus moves to a remaining delete button or the history close button.
- Enter text or click an example question to see the fixed GDPR sample answer. Follow-up questions stay in the same conversation. Answers remain preset for this visual prototype; prototype notices have been removed from the interface at the owner's request.
- Each answer owns its sources and numbering. Square citation tiles display that turn's passage in the right card. The current citation is solid green in both panes; all other citations are dimmed. Clicking from either pane updates the same selection.
- Hovering a citation adds a 1 px stepped shake without moving surrounding text. Turning Motion off disables it.
- Select text inside the passage to open a small composer beside the selection, headed `ask about this passage`. Sending attaches the selected quote and original source to the new question. Clicking elsewhere in either pane dismisses the composer and any unsent draft; clicking or typing inside it keeps it open.
- The passage composer grows to fit the selected quote and shifts to stay within the source pane. Only when it reaches the available viewport height does the quote scroll; the question field and send button remain visible.
- The selected passage stays highlighted while typing in its question box. Closing, sending, or dismissing the box clears that highlight; selection stays confined to the source document.
- `[3]` toggles light/dark mode. `[4] Motion` controls animation; its active state means motion is on. Turning it off stops the canvas, typewriter, cursor blink, and citation shake, displaying a static frame. The initial motion setting respects the operating system preference.
- `[5] instructions`, beside Motion, opens a centered document in the browser's top layer. Usage guidance uses Departure Mono in paragraphs, without repeated hints in the conversation or source panes. Close it with its button, Escape, or a click outside the document. The bracketed navigation numbers are evenly spaced; the final instructions label has room to extend without widening the preceding gaps.
- Conversations, theme, and motion settings use `sessionStorage`, surviving reloads in the same browser tab. New chats do not erase history. No localStorage, question logging, analytics, authentication, or API calls.
- The layout is for desktop (minimum 1120 × 740); it does not switch to a mobile layout.

Example questions and sample answers are Chinese. Input placeholders and send controls are English in Departure Mono; typed questions retain the sans-serif font. Source passages, citation labels, navigation, and instructions are English. The English “Explore GDPR…” line is the sole introductory guidance, set in Departure Mono with a typewriter effect. Characters reveal in their final word positions. The cursor stays steady while typing, disappears immediately when the sentence is complete, then blinks every 550 ms. It never affects line breaks and remains static with Motion off. The placeholder pixel logo remains available for later refinement. Source cards share the history panel's subtle offset shadow.

The fixed demo uses short, verbatim excerpts from GDPR Article 17(1)(a), Article 17(3), and Recital 65, checked against the [official EUR-Lex text](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32016R0679) on 2026-10-05. Source cards are labelled `excerpt`, omissions are marked, and the complete regulation is linked. Chinese summaries are authored sample copy, not live model output. No lecture content is invented. Earlier saved turns refresh their source fixtures and known example questions while retaining other user-entered questions and quotations.

## Structure

Chinese text follows Claude's directly verified live fallback stacks, including PingFang SC / Microsoft YaHei / Noto Sans CJK SC for answers. This replaces the earlier Noto Serif SC / Noto Sans SC choices; see `FONT_NOTES.md` for the evidence and platform behavior.

- `src/App.tsx`: two-column shell, conversations, citation binding, history, and preferences.
- `src/SourcePane.tsx`: isolated source document and selection composer. An iframe confines native text selection to its own document; selection state stays inside the passage component, avoiding answer-panel rerenders during selection.
- `src/PixelField.tsx`: Veiled horizon, a full-width canvas animation of muted green pixel mist. Speed 1.2, visibility 1.4; Motion off shows a deterministic static frame. No graphics or component library.
- `src/model.ts`: visual fixtures and validated session storage.
- `public/fonts.css`, `public/source.css`: shared typefaces and source-document styling.
- `FONT_NOTES.md`: font verification, language decisions, and hosting details.

The original `DECISIONS.md` was read from the provided path and was neither copied nor modified. Backend behavior, API payload schemas, credentials, retrieval, streaming, and last-five-turn request assembly are outside this visual-only prototype. A later integration should preserve the decision file's per-turn citation mapping and history rules.
