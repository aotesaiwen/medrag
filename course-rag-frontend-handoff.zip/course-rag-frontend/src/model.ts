export type Source = { id: string; label: string; unit: string; paragraphs: string[] }
export type Quotation = { text: string; source: Source; turnId: string }
export type Turn = { id: string; question: string; quotation?: Quotation; sources: Source[]; readSourceIds?: string[] }
export type Conversation = { id: string; createdAt: number; turns: Turn[] }
export type Session = {
  version: 1
  conversations: Conversation[]
  activeId: string | null
  theme: 'light' | 'dark'
  reducedMotion: boolean
}

export const STORAGE_KEY = 'course-rag-visual-prototype.v1'
export const PHRASE = 'Explore GDPR, HIPAA and your lecture materials, with source passages alongside each answer.'
export const EXAMPLE_QUESTIONS = [
  '哪些情况下可以请求删除个人数据？',
  '删除权是否适用于所有情况？',
  '如何结合序言理解删除权？',
]
const PREVIOUS_EXAMPLES = [
  'When can personal data be erased?',
  'What are the exceptions to erasure?',
  'How does Recital 65 explain erasure?',
]
export const SOURCE_URL = 'https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32016R0679'
// Short verbatim excerpts, verified against the official English regulation.
// These are excerpts of the cited units, not complete retrieval chunks.
export const SOURCES: Source[] = [
  { id: 'gdpr:art17:p1', label: 'GDPR', unit: 'Article 17 · paragraph 1', paragraphs: [
    '(a) the personal data are no longer necessary in relation to the purposes for which they were collected or otherwise processed;',
  ] },
  { id: 'gdpr:art17:p3', label: 'GDPR', unit: 'Article 17 · paragraph 3', paragraphs: [
    'Paragraphs 1 and 2 shall not apply to the extent that processing is necessary:',
    '(a) for exercising the right of freedom of expression and information;',
    '[…]',
    '(e) for the establishment, exercise or defence of legal claims.',
  ] },
  { id: 'gdpr:rec65', label: 'GDPR', unit: 'Recital 65', paragraphs: [
    'A data subject should have the right to have personal data concerning him or her rectified and a ‘right to be forgotten’ where the retention of such data infringes this Regulation or Union or Member State law to which the controller is subject.',
  ] },
]

export const DEMO_ANSWERS: Record<string, string> = {
  'gdpr:art17:p1': '当个人数据对于最初收集或处理的目的已不再必要时，可以请求删除这些数据。',
  'gdpr:art17:p3': '删除权并非适用于所有情况。例如，为行使言论和信息自由权，或为法律请求的提出、行使或抗辩而有必要处理数据时，可能适用例外。',
  'gdpr:rec65': '序言第65段解释删除权的背景；第17条规定具体条件和例外。',
}

// Fixed visual demo. No model, retrieval, or API call.
export function makeTurn(question: string, quotation?: Quotation): Turn {
  const sources = quotation
    ? [quotation.source, ...SOURCES.filter(source => source.id !== quotation.source.id)]
    : SOURCES
  return { id: crypto.randomUUID(), question, quotation, sources }
}

function validSource(value: unknown): value is Source {
  if (!value || typeof value !== 'object') return false
  const source = value as Source
  return typeof source.id === 'string' && typeof source.label === 'string'
    && typeof source.unit === 'string' && Array.isArray(source.paragraphs)
    && source.paragraphs.every(text => typeof text === 'string')
}

export function readSession(): Session {
  const fallback: Session = {
    version: 1, conversations: [], activeId: null, theme: 'light',
    reducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  }
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY)
    if (!raw) return fallback
    const saved = JSON.parse(raw) as Session
    if (saved.version !== 1 || !Array.isArray(saved.conversations)
      || !['light', 'dark'].includes(saved.theme) || typeof saved.reducedMotion !== 'boolean') return fallback
    if (!saved.conversations.every(c => typeof c.id === 'string' && typeof c.createdAt === 'number'
      && Array.isArray(c.turns) && c.turns.every(t => typeof t.id === 'string'
        && typeof t.question === 'string' && Array.isArray(t.sources) && t.sources.length > 0
        && t.sources.every(validSource) && (!t.quotation || (typeof t.quotation.text === 'string'
          && typeof t.quotation.turnId === 'string' && validSource(t.quotation.source)))))) return fallback
    // Refresh earlier symbol-only fixtures without deleting conversations or user text.
    const conversations = saved.conversations.map(conversation => ({
      ...conversation,
      turns: conversation.turns.map(turn => ({
        ...turn,
        question: refreshExample(turn.question),
        readSourceIds: Array.isArray(turn.readSourceIds)
          ? turn.readSourceIds.filter(id => typeof id === 'string' && turn.sources.some(source => source.id === id))
          : [],
        sources: turn.sources.some(source => source.paragraphs.some(text => text.includes('◇')))
          ? SOURCES : turn.sources,
      })),
    }))
    return { ...saved, conversations, activeId: conversations.some(c => c.id === saved.activeId) ? saved.activeId : null }
  } catch { return fallback }
}

function refreshExample(question: string) {
  const previousIndex = PREVIOUS_EXAMPLES.indexOf(question)
  if (previousIndex !== -1) return EXAMPLE_QUESTIONS[previousIndex]
  const symbolIndex = [1, 2, 3].findIndex(number => question === `◇◇◇ ${'◇'.repeat(number + 1)} ◇◇◇?`)
  return symbolIndex === -1 ? question : EXAMPLE_QUESTIONS[symbolIndex]
}
