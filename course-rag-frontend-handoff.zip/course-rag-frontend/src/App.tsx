import { useEffect, useRef, useState } from 'react'
import { Composer } from './Composer'
import { PixelField } from './PixelField'
import { SourcePane } from './SourcePane'
import { DEMO_ANSWERS, EXAMPLE_QUESTIONS, PHRASE, SOURCE_URL, STORAGE_KEY, makeTurn, readSession } from './model'
import type { Quotation, Turn } from './model'

function PixelLogo({ small = false }: { small?: boolean }) {
  return <svg className={small ? 'pixel-logo small' : 'pixel-logo'} viewBox="0 0 32 32" role="img" aria-label="Placeholder logo" shapeRendering="crispEdges">
    <path fill="currentColor" d="M8 4h12v4H8zm-4 4h4v12H4zm16 0h4v4h-4zm-8 4h8v8h-8zm12 0h4v12h-4zm-16 8h4v4H8zm4 4h12v4H12z" />
  </svg>
}

function Slogan({ reduced }: { reduced: boolean }) {
  const [count, setCount] = useState(0)
  useEffect(() => {
    if (reduced) return
    let next = 0
    let cancelled = false
    let timer: number | undefined
    setCount(0)
    function start() {
      if (cancelled) return
      timer = window.setInterval(() => { next += 1; setCount(next); if (next >= PHRASE.length) clearInterval(timer) }, 35)
    }
    void document.fonts.load('22px "Departure Mono"').then(start, start)
    return () => { cancelled = true; clearInterval(timer) }
  }, [reduced])
  const revealedCount = reduced ? PHRASE.length : count
  const cursorIndex = Math.max(0, PHRASE.slice(0, revealedCount).trimEnd().length - 1)
  return <h1 className="slogan" aria-label={PHRASE}><span aria-hidden="true">
    {Array.from(PHRASE.matchAll(/\S+/g), word => <span key={word.index}>
      <span className="slogan-word">{Array.from(word[0], (character, index) => <span className="slogan-character" key={index}
        style={{ visibility: word.index + index < revealedCount ? 'visible' : 'hidden' }}>
        {character}{word.index + index === cursorIndex && <span className={`type-cursor${revealedCount === 0 ? ' is-start' : ''}${!reduced && count >= PHRASE.length ? ' is-idle' : ''}`} />}
      </span>)}</span>
      {word.index + word[0].length < PHRASE.length ? ' ' : null}
    </span>)}
  </span></h1>
}

function CitationTile({ number, label, active, onClick }: {
  number: number; label: string; active: boolean; onClick: () => void
}) {
  return <button type="button" className="citation-tile" aria-label={label} aria-pressed={active} onClick={onClick}>{number}</button>
}

function InstructionsDocument({ onClose }: { onClose: () => void }) {
  const dialogRef = useRef<HTMLDialogElement>(null)
  useEffect(() => {
    const dialog = dialogRef.current!
    dialog.showModal()
    return () => dialog.close()
  }, [])
  function close() { dialogRef.current?.close(); onClose() }
  return <dialog ref={dialogRef} id="instructions-panel" className="instructions-document" aria-labelledby="instructions-title"
    onCancel={event => { event.preventDefault(); close() }}
    onClick={event => {
      if (event.target !== event.currentTarget) return
      const rect = event.currentTarget.getBoundingClientRect()
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) close()
    }}>
    <header><h2 id="instructions-title">instructions</h2><button type="button" onClick={close} aria-label="Close instructions" autoFocus>close</button></header>
    <div className="instructions-copy">
      <p>Ask a question or choose an example, then continue the conversation in the follow-up box. Press Enter to send, or Shift + Enter to start a new line.</p>
      <p>Click a numbered citation to read its source beside the answer. The current citation is solid green in both panes. Other citations are dimmed. Each answer keeps its own sources.</p>
      <p>Select text within a source to ask about that passage. Your question includes the selected text. Click outside the small composer or press Escape to dismiss it without sending.</p>
      <p>Use chat to start a new conversation and history to return to an earlier one. Delete removes a conversation from this browser tab. Deleting the open conversation returns you to a new chat.</p>
      <p>The theme control switches between light and dark. Motion turns animations on or off. With Motion off, the background shows a static frame and the typewriter and citation animations stop.</p>
    </div>
  </dialog>
}

function Answer({ turn, number, active, onCitation }: {
  turn: Turn; number: number; active: { turnId: string; index: number } | null
  onCitation: (turnId: string, index: number) => void
}) {
  return <article className="turn" data-turn-id={turn.id}>
    <div className="user-message" lang="zh-CN">
      {turn.quotation && <blockquote className="user-quotation"><span>{turn.quotation.source.label} / {turn.quotation.source.unit}</span>{turn.quotation.text}</blockquote>}
      <p>{turn.question}</p>
    </div>
    <div className="answer"><PixelLogo small />
      <div className="answer-body" lang="zh-CN" aria-label="Sample answer">
        {turn.sources.map((source, index) => DEMO_ANSWERS[source.id] && <p key={source.id}>{DEMO_ANSWERS[source.id]} <CitationTile number={index + 1} label={`Open citation ${index + 1}, answer ${number}`} active={active?.turnId === turn.id && active.index === index} onClick={() => onCitation(turn.id, index)} /></p>)}
      </div>
    </div>
  </article>
}

export default function App() {
  const [session, setSession] = useState(readSession)
  const [historyOpen, setHistoryOpen] = useState(false)
  const [instructionsOpen, setInstructionsOpen] = useState(false)
  const [activeCitation, setActiveCitation] = useState<{ turnId: string; index: number } | null>(null)
  const [storageFailed, setStorageFailed] = useState(false)
  const transcriptRef = useRef<HTMLDivElement>(null)
  const historyButtonRef = useRef<HTMLButtonElement>(null)
  const historyCloseButtonRef = useRef<HTMLButtonElement>(null)
  const instructionsButtonRef = useRef<HTMLButtonElement>(null)
  const activeConversation = session.conversations.find(c => c.id === session.activeId)
  const turns = activeConversation?.turns ?? []
  const lastTurn = turns[turns.length - 1]
  const chosenTurn = turns.find(t => t.id === activeCitation?.turnId) ?? lastTurn
  const chosenIndex = activeCitation && chosenTurn?.id === activeCitation.turnId ? activeCitation.index : 0
  const chosenSource = chosenTurn?.sources[chosenIndex]
  const hasConversation = turns.length > 0

  useEffect(() => {
    document.documentElement.dataset.theme = session.theme
    document.documentElement.dataset.reduced = String(session.reducedMotion)
    try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify(session)); setStorageFailed(false) }
    catch { setStorageFailed(true) }
  }, [session])

  useEffect(() => {
    const element = transcriptRef.current
    if (element) element.scrollTo({ top: element.scrollHeight, behavior: 'instant' })
  }, [turns.length, session.activeId])

  useEffect(() => {
    if (!historyOpen) return
    function escape(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setHistoryOpen(false); historyButtonRef.current?.focus()
      }
    }
    document.addEventListener('keydown', escape)
    return () => document.removeEventListener('keydown', escape)
  }, [historyOpen])

  function submit(question: string, quotation?: Quotation) {
    const turn = makeTurn(question, quotation)
    setSession(previous => {
      const existing = previous.conversations.find(c => c.id === previous.activeId)
      if (existing) return { ...previous, conversations: previous.conversations.map(c => c.id === existing.id ? { ...c, turns: [...c.turns, turn] } : c) }
      const conversation = { id: crypto.randomUUID(), createdAt: Date.now(), turns: [turn] }
      return { ...previous, activeId: conversation.id, conversations: [conversation, ...previous.conversations] }
    })
    setActiveCitation({ turnId: turn.id, index: 0 })
    setHistoryOpen(false)
    setInstructionsOpen(false)
  }
  function newChat() {
    setSession(previous => ({ ...previous, activeId: null }))
    setActiveCitation(null); setHistoryOpen(false); setInstructionsOpen(false)
  }
  function deleteConversation(id: string, button: HTMLButtonElement) {
    const row = button.closest('li')
    const nextRow = row?.nextElementSibling ?? row?.previousElementSibling
    const nextButton = nextRow?.querySelector<HTMLButtonElement>('.history-delete')
    setSession(previous => ({
      ...previous,
      conversations: previous.conversations.filter(conversation => conversation.id !== id),
      activeId: previous.activeId === id ? null : previous.activeId,
    }))
    if (session.activeId === id) setActiveCitation(null)
    ;(nextButton ?? historyCloseButtonRef.current)?.focus()
  }
  function openCitation(turnId: string, index: number) {
    const source = turns.find(turn => turn.id === turnId)?.sources[index]
    if (!source) return
    setActiveCitation({ turnId, index })
  }

  return <div className={`app-shell ${hasConversation ? 'conversation-mode' : ''}`}>
    <header className="masthead">
      <button type="button" className="brand" onClick={newChat} aria-label="Medical Data Privacy and Ethics in the Age of Artificial Intelligence — New chat"><PixelLogo /><span className="brand-title">Medical Data Privacy and Ethics<br />in the Age of Artificial Intelligence</span></button>
      <nav aria-label="Main navigation">
        <button type="button" onClick={newChat}><span className="nav-number">[1]</span> chat</button>
        <button type="button" ref={historyButtonRef} onClick={() => { setHistoryOpen(value => !value); setInstructionsOpen(false) }} aria-expanded={historyOpen} aria-controls="history-panel"><span className="nav-number">[2]</span> history</button>
        <button type="button" onClick={() => setSession(previous => ({ ...previous, theme: previous.theme === 'light' ? 'dark' : 'light' }))} aria-label={`Switch to ${session.theme === 'light' ? 'dark' : 'light'} mode`}><span className="nav-number">[3]</span> {session.theme}</button>
        <button type="button" onClick={() => setSession(previous => ({ ...previous, reducedMotion: !previous.reducedMotion }))} aria-pressed={!session.reducedMotion}><span className="nav-number">[4]</span> Motion</button>
        <button type="button" ref={instructionsButtonRef} onClick={() => { setInstructionsOpen(true); setHistoryOpen(false) }} aria-haspopup="dialog" aria-expanded={instructionsOpen} aria-controls="instructions-panel"><span className="nav-number">[5]</span> instructions</button>
      </nav>
    </header>

    <main className="workspace">
      <section className="left-panel" aria-label={hasConversation ? 'Conversation' : 'Introduction'}>
        {hasConversation ? <>
          <div className="transcript" ref={transcriptRef}>
            {turns.map((turn, index) => <Answer key={turn.id} turn={turn} number={index + 1}
              active={activeCitation ?? (chosenTurn ? { turnId: chosenTurn.id, index: chosenIndex } : null)}
              onCitation={openCitation} />)}
          </div>
          <div className="follow-up"><Composer compact onSend={submit} /></div>
        </> : <>
          <div className="intro-body">
            <Slogan reduced={session.reducedMotion} />
          </div>
          <ol className="reference-list" aria-label="Course materials">
            {[
              ['GDPR', 'Articles and recitals'],
              ['HIPAA', 'Selected privacy and security provisions'],
              ['Lecture slides', 'Materials organised by lecture'],
            ].map(([label, description], index) => <li key={label}><span className="list-number">0{index + 1}</span><div><span>{label}</span><p>{description}</p></div></li>)}
          </ol>
        </>}
      </section>

      <section className="right-panel" aria-label={hasConversation ? 'Source workspace' : 'Chat workspace'}>
        <div className={`center-card ${hasConversation ? 'source-card' : 'welcome-card'}`}>
          {hasConversation && chosenSource && chosenTurn ? <>
            <header className="source-header"><div><span className="eyebrow">{chosenSource.label} / excerpt</span><h2>{chosenSource.unit}</h2></div><a className="source-link" href={SOURCE_URL} target="_blank" rel="noreferrer">EUR-Lex ↗</a></header>
            <div className="source-body"><div className="source-rail" aria-label="Sources for selected answer">{chosenTurn.sources.map((source, index) => <CitationTile key={source.id} number={index + 1} label={`View source ${index + 1}: ${source.label} ${source.unit}`} active={chosenIndex === index} onClick={() => openCitation(chosenTurn.id, index)} />)}</div>
              <SourcePane source={chosenSource} turnId={chosenTurn.id} theme={session.theme} reduced={session.reducedMotion} onAsk={submit} />
            </div>
            <PixelField compact reduced={session.reducedMotion} dark={session.theme === 'dark'} />
          </> : <>
            <div className="welcome-content">
              <Composer onSend={submit} />
              <div className="example-questions" aria-label="Example questions">{EXAMPLE_QUESTIONS.map((question, index) => <button type="button" key={question} onClick={() => submit(question)}><span className="example-index">0{index + 1}</span><span lang="zh-CN">{question}</span><span aria-hidden="true">↗</span></button>)}</div>
            </div>
            <PixelField reduced={session.reducedMotion} dark={session.theme === 'dark'} />
          </>}
        </div>
      </section>
    </main>

    {historyOpen && <><button type="button" className="history-backdrop" aria-label="Close history" onClick={() => setHistoryOpen(false)} />
      <aside id="history-panel" className="history-panel" aria-label="Conversation history"><header><button type="button" ref={historyCloseButtonRef} onClick={() => { setHistoryOpen(false); historyButtonRef.current?.focus() }} aria-label="Close history">×</button></header>
        {session.conversations.length === 0 ? <p className="history-empty">No conversations yet</p> : <ol>{session.conversations.map((conversation, index) => <li key={conversation.id}><button type="button" className="history-open" aria-current={session.activeId === conversation.id ? 'true' : undefined} onClick={() => {
          setSession(previous => ({ ...previous, activeId: conversation.id })); setActiveCitation(null); setHistoryOpen(false)
        }}><span className="history-index">{String(index + 1).padStart(2, '0')}</span><span className="history-title">{conversation.turns[0]?.question ?? 'New conversation'}</span></button>
          <button type="button" className="history-delete" aria-label={`Delete conversation: ${conversation.turns[0]?.question ?? 'New conversation'}`} onClick={event => deleteConversation(conversation.id, event.currentTarget)}>delete</button>
        </li>)}</ol>}
      </aside></>}
    {instructionsOpen && <InstructionsDocument onClose={() => { setInstructionsOpen(false); instructionsButtonRef.current?.focus() }} />}
    {storageFailed && <div role="status" className="storage-status">Conversation history cannot be saved in this tab.</div>}
  </div>
}
