# Typography verification

Verified and researched on 2026-10-05.

Chinese questions and answers now follow Claude's live font fallback declarations, directly inspected on 2026-10-05. This supersedes the earlier role-preserving Noto Serif SC / Noto Sans SC choice. English answers and passages use Anthropic Serif; English inputs use Anthropic Sans. The sole “Explore GDPR…” guidance uses Departure Mono at 22 px. No Chinese pixel font is included.

Input placeholders use Departure Mono at 14 px, including both follow-up composers. Send controls remain at the font's native 11 px size. The placeholder styling does not change the font of typed questions.

The instructions document uses Departure Mono throughout, with 18 px body text. Posted queries and answers both use 19 px type with a 1.8 line height, retaining their respective sans-serif and serif families.

| Role | Latin | Simplified Chinese |
| --- | --- | --- |
| Answers, passages, serif display text | Anthropic Serif | Claude's CJK stack: PingFang SC, Microsoft YaHei, Noto Sans CJK SC, then its other CJK fallbacks |
| User text and text inputs | Anthropic Sans | Claude's user-message stack: system UI and OS fallbacks, including PingFang SC |
| Navigation and interface controls | Departure Mono | Claude's Simplified Chinese fallback stack when a control requires Chinese glyphs |

## Evidence and limits

- **Anthropic Serif**: verified in [Anthropic's official stylesheet](https://cdn.prod.website-files.com/67ce28cfec624e2b733f8a52/css/ant-brand.shared.11407e92c.min.css). The linked Roman WOFF2 was inspected with fontTools: typographic family `Anthropic Serif Web`, variable weight axis 300–800 and optical-size axis 16–48. The official CSS names it `Anthropic Serif`. It has no Chinese glyph for 中, so Chinese follows the verified Claude CJK fallback stack. The prototype references the official CDN with a local-family option, without redistributing the font in this repository. Browser loading was verified. The Claude Code renderer itself was not inspected.
- **Anthropic Sans**: the exact name and variable weight range 300–800 were verified in [Anthropic's current first-party stylesheet](https://cdn.prod.website-files.com/67ce28cfec624e2b733f8a52/css/ant-brand.shared.11407e92c.min.css), linked from [anthropic.com](https://www.anthropic.com/). The prototype loads that family's Roman webfont from the same official CDN, with `local('Anthropic Sans')` first. No renamed Inter, Arial, or Styrene substitute is supplied. Anthropic Sans is not redistributed in this repository; its rendering requires the owner's CDN or a locally installed copy.
- **Claude app, live verification**: the public [Claude sign-in page](https://claude.ai/login) loaded successfully for this update. Its rendered CSS exposes `--font-claude-response`, `--font-user-message`, `--font-cjk-serif-fallback`, and `--font-cjk-serif-sc`. The last token is exactly `"PingFang SC", "Microsoft YaHei", "Noto Sans CJK SC"`. The implementation copies the full CJK response fallback list and the full user-message stack, adapting only the Latin face alias to the already-loaded Anthropic Sans. These declarations were read directly from the live page, replacing reliance on older third-party captures. No account sign-in or private conversation access was needed.
- **Windows availability**: the Windows font registry confirms Microsoft YaHei is installed as `msyh.ttc` (with bold and light variants). No proprietary system font was downloaded or redistributed. Fallback rendering remains platform-dependent, as in Claude's stack.
- **Chinese role decision**: the user's latest explicit request to use Claude's Chinese font supersedes the earlier Noto role-preserving decision. Chinese responses therefore use Claude's sans-serif CJK fallbacks even though Latin responses remain serif.
- **Newsreader (retired from the active type stack)**: originally verified against [Production Type's source repository](https://github.com/productiontype/Newsreader); fetched using the official Google Fonts stylesheet.
- **Departure Mono**: fetched from [the creator's site](https://departuremono.com/). The [font source and releases](https://github.com/rektdeckard/departure-mono) identify the family and SIL Open Font License.
- **Noto Serif SC / Noto Sans SC (retired from the active type stacks)**: fetched using Google Fonts; family/category details are available in Google's [Noto Serif SC metadata](https://github.com/google/fonts/blob/main/ofl/notoserifsc/METADATA.pb) and [Noto Sans SC metadata](https://github.com/google/fonts/blob/main/ofl/notosanssc/METADATA.pb). Their existing local files remain, but no active style requests these families. Claude's `Noto Sans CJK SC` is a distinct named system fallback, not an alias for these downloaded faces.

The open fonts are stored locally in `public/fonts/`; their licenses are in `public/fonts/licenses/`. Unused historical font declarations do not determine the active stacks. An unavailable remote Anthropic face can still trigger browser fallback. The parent document and isolated source document use the same updated Chinese stacks.
